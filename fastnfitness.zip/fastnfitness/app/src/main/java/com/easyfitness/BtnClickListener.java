package com.easyfitness;

/**
 * Created by ccombes on 17/09/20.
 */

public interface BtnClickListener {
    void onBtnClick(long id);
}
